﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическое_занятие_13
{
    class Student
    {
        private string name;
        private string surname;
        private string recordBookNumber;
        public Student(string name,string surname,string recordBookNumber)
        {
            this.name = name;
            this.surname = surname;
            this.recordBookNumber = recordBookNumber;
        }
        public string getName()
        {
            return this.name;
        }
        public void setName(string surname)
        {
            this.name = name;
        }
        public string getSurname()
        {
            return this.surname;
        }
        public void setSurname(string surname)
        {
            this.surname = surname;
        }
        public string getRecordBookNumber()
        {
            return this.recordBookNumber;
        }
        public void setRecordBookNumber(string recordBookNumber)
        {
            this.recordBookNumber = recordBookNumber;
        }
    }
}
